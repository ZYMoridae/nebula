create view vendor_info(username, telephone, address1, address2, firstname, lastname, gender, email) as
SELECT "user".username,
       "user".telephone,
       "user".address1,
       "user".address2,
       "user".firstname,
       "user".lastname,
       "user".gender,
       "user".email
FROM "user";

alter table vendor_info
    owner to yuezhou;

